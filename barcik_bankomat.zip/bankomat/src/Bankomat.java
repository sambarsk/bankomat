import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class Bankomat {

    public static void main(String[] args) {

        BeznyUcet ucet1B = new BeznyUcet(1000);
        BeznyUcet ucet2B = new BeznyUcet(5000);
        BeznyUcet ucet3B = new BeznyUcet(10000);

        SporiaciUcet ucet1S = new SporiaciUcet(1000);
        SporiaciUcet ucet2S = new SporiaciUcet(5000);
        SporiaciUcet ucet3S = new SporiaciUcet(10000);

        JFrame window = new JFrame("Bankomat");
        window.setSize(300, 401);
        window.getContentPane().setBackground(Color.GRAY);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField display = new JTextField("Zadaj ID a stlač A");
        display.setEditable(false);
        display.setBounds(10, 30, 250, 50);

        JTextField display2 = new JTextField();
        display2.setBounds(10, 81, 250, 50);

        JButton buttonSeven = new JButton("7");
        buttonSeven.setBounds(10, 150, 50, 50);

        JButton buttonEight = new JButton("8");
        buttonEight.setBounds(60, 150, 50, 50);

        JButton buttonNine = new JButton("9");
        buttonNine.setBounds(110, 150, 50, 50);

        JButton buttonFour = new JButton("4");
        buttonFour.setBounds(10, 200, 50, 50);

        JButton buttonFive = new JButton("5");
        buttonFive.setBounds(60, 200, 50, 50);

        JButton buttonSix = new JButton("6");
        buttonSix.setBounds(110, 200, 50, 50);

        JButton buttonOne = new JButton("1");
        buttonOne.setBounds(10, 250, 50, 50);

        JButton buttonTwo = new JButton("2");
        buttonTwo.setBounds(60, 250, 50, 50);

        JButton buttonThree = new JButton("3");
        buttonThree.setBounds(110, 250, 50, 50);

        JButton buttonZero = new JButton("0");
        buttonZero.setBounds(10, 300, 50, 50);

        JButton buttonDort = new JButton(".");
        buttonDort.setBounds(60, 300, 50, 50);

        JButton buttonCE = new JButton("C");
        buttonCE.setBounds(110, 300, 50, 50);

        JButton buttonAOption = new JButton("A");
        buttonAOption.setBounds(180, 200, 50, 50);

        JButton buttonBOption = new JButton("B");
        buttonBOption.setBounds(180, 250, 50, 50);

        JButton buttonCOption = new JButton("C");
        buttonCOption.setBounds(180, 300, 50, 50);

        buttonSeven.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "7");
            }
        });

        buttonEight.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "8");
            }
        });

        buttonNine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "9");
            }
        });

        buttonFour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "4");
            }
        });

        buttonFive.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "5");
            }
        });

        buttonSix.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "6");
            }
        });

        buttonOne.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "1");
            }
        });

        buttonTwo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "2");
            }
        });

        buttonThree.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "3");
            }
        });

        buttonZero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + "0");
            }
        });

        buttonDort.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText(existingText + ".");
            }
        });

        buttonCE.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String existingText = display2.getText();
                display2.setText("");
            }
        });

        final int[] status = {0};
        final int[] ucet = {-1};

        buttonAOption.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (status[0] == 31) {

                    if (ucet[0] == 0) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet1B.vloz(hodnota);
                        display.setText("A. Ciastka: " + ucet1B.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else if (ucet[0] == 1) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet2B.vloz(hodnota);
                        display.setText("A. Ciastka: " + ucet2B.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet3B.vloz(hodnota);
                        display.setText("A. Ciastka: " + ucet3B.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                }

                if (status[0] == 32) {

                    if (ucet[0] == 0) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet1S.vloz(hodnota);
                        display.setText("A. Ciastka: " + ucet1S.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else if (ucet[0] == 1) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet2S.vloz(hodnota);
                        display.setText("A. Ciastka: " + ucet2S.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet3S.vloz(hodnota);
                        display.setText("A. Ciastka: " + ucet3S.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                }

                if (status[0] == 2) {

                    status[0] = 31;
                    display.setText("Bezny ucet, zadaj ciastku, A-vloz, B-vyber");
                }

                if (status[0] == 1) {

                    try {

                        FileReader fileReader = new FileReader("ucty_hesla.txt");
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        String line;
                        String textFromDisplay = display2.getText();
                        System.out.println(textFromDisplay);
                        while ((line = bufferedReader.readLine()) != null) {

                            String[] parts = line.split(" ", 2);

                            String secondPart = parts[1];
                            if (secondPart.equals(textFromDisplay)) {

                                status[0] = 2;
                                display.setText("Spravne, typ uctu:  A-Bezny, B-Sporiaci, C-Koniec");
                                display2.setText("");
                                break;
                            }
                        }

                        if (status[0] == 1) {

                            display.setText("Zadal si zle heslo, skus znova");
                            display2.setText("");
                        }

                        bufferedReader.close();
                    }
                    catch (IOException ex) {

                        throw new RuntimeException(ex);
                    }
                }

                if (status[0] == 0) {

                    try {
                        FileReader fileReader = new FileReader("ucty_hesla.txt");
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        String line;
                        String textFromDisplay = display2.getText();
                        System.out.println(textFromDisplay);
                        while ((line = bufferedReader.readLine()) != null) {

                            String[] parts = line.split(" ", 2);

                            String firstPart = parts[0];
                            if (firstPart.equals(textFromDisplay)) {

                                status[0] = 1;
                                display.setText("Zadal si spravne ID, teraz zadaj heslo");
                                display2.setText("");
                                ucet[0] = Integer.parseInt(firstPart.substring(firstPart.length() - 1));
                                break;
                            }
                        }

                        if (status[0] == 0) {

                            display.setText("Zadal si zle ID, skus znova");
                            display2.setText("");
                        }

                        bufferedReader.close();

                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });

        buttonBOption.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (status[0] == 31) {

                    if (ucet[0] == 0) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet1B.vyber(hodnota);
                        display.setText("A. Ciastka: " + ucet1B.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else if (ucet[0] == 1) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet2B.vyber(hodnota);
                        display.setText("A. Ciastka: " + ucet2B.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet3B.vyber(hodnota);
                        display.setText("A. Ciastka: " + ucet3B.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                }

                if (status[0] == 32) {

                    if (ucet[0] == 0) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet1S.vyber(hodnota);
                        display.setText("A. Ciastka: " + ucet1S.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else if (ucet[0] == 1) {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet2S.vyber(hodnota);
                        display.setText("A. Ciastka: " + ucet2S.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                    else {

                        double hodnota = Double.parseDouble(display2.getText());
                        ucet3S.vyber(hodnota);
                        display.setText("A. Ciastka: " + ucet3S.getAktualnyZostatok() + ", odhlas sa C");
                        display2.setText("");
                    }
                }

                if (status[0] == 2) {

                    status[0] = 32;
                    display.setText("Sporiaci ucet, zadaj ciastku, A-vloz, B-vyber");
                }
            }
        });

        buttonCOption.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (status[0] > 0) {

                    status[0] = 0;
                    ucet[0] = -1;
                    display.setText("Bol si odhlaseny, zadaj ID");
                }
            }
        });


        window.add(buttonCOption);
        window.add(buttonBOption);
        window.add(buttonAOption);
        window.add(buttonCE);
        window.add(buttonDort);
        window.add(buttonZero);
        window.add(buttonThree);
        window.add(buttonTwo);
        window.add(buttonOne);
        window.add(buttonSix);
        window.add(buttonFive);
        window.add(buttonFour);
        window.add(buttonNine);
        window.add(buttonEight);
        window.add(buttonSeven);
        window.add(display);
        window.add(display2);
        window.setLayout(null);
        window.setVisible(true);
    }
}
