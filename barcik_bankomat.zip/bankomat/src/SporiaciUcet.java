public class SporiaciUcet extends BeznyUcet{

    public SporiaciUcet(double aktualnyZostatok) {

        super(aktualnyZostatok);
    }

    public void pripisUrok(double urokPercenta) {

        double aktualnyZostatok = getAktualnyZostatok();
        double urokCiastka = (aktualnyZostatok * urokPercenta) / 100.0;
        vloz(urokCiastka);
    }
}
