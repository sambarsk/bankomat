public class BeznyUcet {

    private double aktualnyZostatok;

    public BeznyUcet(double aktualnyZostatok) {

        this.aktualnyZostatok = aktualnyZostatok;
    }

    public void vloz(double ciastka) {

        aktualnyZostatok += ciastka;
    }

    public void vyber(double ciastka) {

        aktualnyZostatok -= ciastka;
    }

    public double getAktualnyZostatok() {

        return aktualnyZostatok;
    }
}
